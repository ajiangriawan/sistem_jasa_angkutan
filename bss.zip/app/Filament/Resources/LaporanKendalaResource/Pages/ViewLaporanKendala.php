<?php

namespace App\Filament\Resources\LaporanKendalaResource\Pages;

use App\Filament\Resources\LaporanKendalaResource;
use Filament\Actions;
use Filament\Resources\Pages\ViewRecord;

class ViewLaporanKendala extends ViewRecord
{
    protected static string $resource = LaporanKendalaResource::class;
}
