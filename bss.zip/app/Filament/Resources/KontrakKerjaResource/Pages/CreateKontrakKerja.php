<?php

namespace App\Filament\Resources\KontrakKerjaResource\Pages;

use App\Filament\Resources\KontrakKerjaResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateKontrakKerja extends CreateRecord
{
    protected static string $resource = KontrakKerjaResource::class;
}
