<?php

namespace App\Filament\Resources\PermintaanResource\Pages;

use App\Filament\Resources\PermintaanResource;
use Filament\Resources\Pages\ViewRecord;

class ViewPermintaan extends ViewRecord
{
    protected static string $resource = PermintaanResource::class;

}
