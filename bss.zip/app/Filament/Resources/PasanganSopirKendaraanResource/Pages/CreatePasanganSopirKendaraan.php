<?php

namespace App\Filament\Resources\PasanganSopirKendaraanResource\Pages;

use App\Filament\Resources\PasanganSopirKendaraanResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreatePasanganSopirKendaraan extends CreateRecord
{
    protected static string $resource = PasanganSopirKendaraanResource::class;
}
