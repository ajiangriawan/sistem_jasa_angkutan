<div class="space-y-4">
    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="border rounded p-2">
            <iframe src="<?php echo e(asset('storage/' . $file)); ?>" class="w-full h-96"></iframe>
            <div class="mt-2 mt-2 text-center">
                <a href="<?php echo e(asset('storage/' . $file)); ?>" target="_blank" class="text-blue-500 underline">
                    Download File
                </a>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH D:\Skripsi\Episode 2\pt-balink-sakti-synergy\resources\views/filament/resources/permintaan-resource/preview.blade.php ENDPATH**/ ?>