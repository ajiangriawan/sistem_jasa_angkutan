<div class="space-y-4">
    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $dokumenList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $path): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="p-4 border rounded shadow-sm bg-white">
            <h3 class="font-semibold text-gray-700"><?php echo e($documentName); ?> #<?php echo e($index + 1); ?></h3>
            <iframe src="<?php echo e(Storage::url($path)); ?>" class="w-full h-96 mt-2 rounded" frameborder="0"></iframe>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH D:\Skripsi\Episode 2\pt-balink-sakti-synergy\resources\views/filament/modals/document-viewer-list.blade.php ENDPATH**/ ?>