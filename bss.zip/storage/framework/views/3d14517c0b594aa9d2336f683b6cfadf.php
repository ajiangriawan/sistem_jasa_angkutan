
<?php
// Variabel $path dan $documentName akan dilewatkan dari PHP
?>

<div class="p-4">
    <!--[if BLOCK]><![endif]--><?php if(empty($path)): ?>
    
    <div class="filament-forms-components-placeholder flex items-center justify-center h-48 bg-gray-100 rounded-lg border border-dashed border-gray-300 dark:bg-gray-800 dark:border-gray-700">
        <span class="text-gray-500 dark:text-gray-400 text-center">
            Dokumen <?php echo e($documentName ?? 'ini'); ?> belum diunggah atau tidak ditemukan.
        </span>
    </div>
    <?php else: ?>
    
    <div class="border rounded p-2">
        <iframe src="<?php echo e(asset('storage/' . $path)); ?>" class="w-full h-96" frameborder="0"></iframe>

        
        <div class="mt-2 text-center">
            <a href="<?php echo e(asset('storage/' . $path)); ?>" target="_blank" class="text-blue-500 underline hover:text-blue-700">
                Unduh Dokumen
            </a>
        </div>
    </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div><?php /**PATH D:\Skripsi\Episode 2\pt-balink-sakti-synergy\resources\views/filament/modals/document-viewer.blade.php ENDPATH**/ ?>